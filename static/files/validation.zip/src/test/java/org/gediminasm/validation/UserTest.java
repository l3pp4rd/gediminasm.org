package org.gediminasm.validation;

import org.junit.Test;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Optional;

import static com.github.npathai.hamcrestopt.OptionalMatchers.hasValue;
import static com.github.npathai.hamcrestopt.OptionalMatchers.isEmpty;
import static org.hamcrest.MatcherAssert.assertThat;

public class UserTest {

    private static Validator userValidator(final User user) {
        return user == null ? Optional::empty : new Group(
                Field.of("username", new Group(
                        new NotNullValidator(user.username()),
                        SizeValidator.range(user.username(), 1, 16)
                )),
                Field.of("roles", new Group(
                        new NotNullValidator(user.roles()),
                        SizeValidator.range(user.roles(), 1, Integer.MAX_VALUE)
                ))
        );
    }

    @Test
    public void shouldPassOnValidUser() {
        final User user = new User("gediminas", new HashSet<>(Arrays.asList("admin", "guest")));

        assertThat(userValidator(user).valid(), isEmpty());
    }

    @Test
    public void shouldFailIfUsernameLengthIsAboveValid() {
        final User user = new User(String.format("%17d", 1), null);

        assertThat(userValidator(user).valid(), hasValue("\"username\" size is above maximum allowed 16"));
    }
}
