package org.gediminasm.validation;

import org.jetbrains.annotations.NotNull;

import java.util.Optional;

@FunctionalInterface
public interface Validator {

    /**
     * Validates and maybe returns an error message
     *
     * @return maybe error message
     */
    @NotNull Optional<String> valid();
}
